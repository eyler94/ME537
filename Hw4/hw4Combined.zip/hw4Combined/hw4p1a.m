clear
close all
clc

mdl_3link3d

R3.teach